/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject9;

/**
 *
 * @author elias
 */
public class Mavenproject9 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
